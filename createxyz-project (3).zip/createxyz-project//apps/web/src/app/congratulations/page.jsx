'use client';

import { useState, useEffect } from 'react';
import { CheckCircle, GraduationCap, Calendar, User, ArrowRight, Sparkles } from 'lucide-react';

export default function CongratulationsPage() {
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get student data from localStorage
    const studentData = localStorage.getItem('student');
    if (studentData) {
      setStudent(JSON.parse(studentData));
    } else {
      // Redirect to home if no student data
      window.location.href = '/';
    }
    setLoading(false);
  }, []);

  const navigateTo = (path) => {
    window.location.href = path;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <button 
              onClick={() => navigateTo('/')}
              className="flex items-center space-x-3"
            >
              <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-green-600 rounded-xl flex items-center justify-center">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">JO Educational Consultancy</h1>
                <p className="text-sm text-gray-600">Small Effort, Great Change</p>
              </div>
            </button>
            <nav className="hidden md:flex space-x-6">
              <button 
                onClick={() => navigateTo('/profile')}
                className="text-gray-600 hover:text-blue-600 font-medium transition-colors"
              >
                Profile
              </button>
              <button 
                onClick={() => navigateTo('/events')}
                className="text-gray-600 hover:text-blue-600 font-medium transition-colors"
              >
                Events
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Congratulations Content */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          {/* Success Animation */}
          <div className="relative mb-8">
            <div className="w-32 h-32 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-6 relative overflow-hidden">
              <CheckCircle className="w-16 h-16 text-white" />
              <div className="absolute inset-0 bg-white opacity-20 animate-pulse rounded-full"></div>
            </div>
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-4">
              <Sparkles className="w-8 h-8 text-yellow-400 animate-bounce" />
            </div>
            <div className="absolute top-8 right-1/2 transform translate-x-16">
              <Sparkles className="w-6 h-6 text-pink-400 animate-pulse" />
            </div>
            <div className="absolute top-8 left-1/2 transform -translate-x-16">
              <Sparkles className="w-6 h-6 text-purple-400 animate-bounce" style={{ animationDelay: '0.5s' }} />
            </div>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            🎉 Congratulations! 🎉
          </h2>
          
          {student && (
            <p className="text-2xl text-gray-700 mb-4">
              Welcome to JO Educational Consultancy, <span className="text-blue-600 font-semibold">{student.full_name}</span>!
            </p>
          )}

          <p className="text-xl text-gray-600 mb-12 max-w-2xl mx-auto">
            Your registration was successful! You're now part of our educational community dedicated to helping you achieve your academic goals.
          </p>

          {/* Success Details */}
          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">What's Next?</h3>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-6 bg-blue-50 rounded-xl">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <User className="w-8 h-8 text-blue-600" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Complete Your Profile</h4>
                <p className="text-gray-600 text-sm mb-4">
                  Add more details to your profile to get personalized recommendations
                </p>
                <button
                  onClick={() => navigateTo('/profile')}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium"
                >
                  View Profile
                </button>
              </div>

              <div className="text-center p-6 bg-green-50 rounded-xl">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Calendar className="w-8 h-8 text-green-600" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Explore Events</h4>
                <p className="text-gray-600 text-sm mb-4">
                  Browse our upcoming workshops, seminars, and educational events
                </p>
                <button
                  onClick={() => navigateTo('/events')}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium"
                >
                  View Events
                </button>
              </div>

              <div className="text-center p-6 bg-purple-50 rounded-xl">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <GraduationCap className="w-8 h-8 text-purple-600" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">Start Learning</h4>
                <p className="text-gray-600 text-sm mb-4">
                  Access our educational resources and begin your learning journey
                </p>
                <button
                  onClick={() => navigateTo('/')}
                  className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium"
                >
                  Explore Resources
                </button>
              </div>
            </div>
          </div>

          {/* Registration Summary */}
          {student && (
            <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-8 mb-12">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Registration Summary</h3>
              <div className="grid md:grid-cols-2 gap-6 text-left">
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">Personal Information</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="text-gray-500">Name:</span> {student.full_name}</p>
                    <p><span className="text-gray-500">Email:</span> {student.email}</p>
                    {student.phone && <p><span className="text-gray-500">Phone:</span> {student.phone}</p>}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-700 mb-2">Academic Information</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="text-gray-500">Education Level:</span> {student.education_level || 'Not specified'}</p>
                    <p><span className="text-gray-500">Registration Date:</span> {new Date().toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Call to Action */}
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Ready to Begin Your Educational Journey?</h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
              Join thousands of students who have transformed their academic careers with our expert guidance and comprehensive support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => navigateTo('/profile')}
                className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center justify-center space-x-2"
              >
                <User className="w-5 h-5" />
                <span>Complete Profile</span>
              </button>
              <button
                onClick={() => navigateTo('/events')}
                className="bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors flex items-center justify-center space-x-2"
              >
                <span>Explore Events</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h5 className="text-xl font-bold">JO Educational Consultancy</h5>
              <p className="text-sm text-gray-400">Small Effort, Great Change</p>
            </div>
          </div>
          <p className="text-gray-400">
            © 2025 JO Educational Consultancy. All rights reserved.
          </p>
        </div>
      </footer>

      <style jsx global>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        .animate-float {
          animation: float 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}