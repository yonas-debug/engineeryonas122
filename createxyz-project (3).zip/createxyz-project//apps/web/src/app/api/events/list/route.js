import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    // Get all upcoming events
    const events = await sql`
      SELECT id, title, description, event_date, event_time, location, max_participants, created_at
      FROM events 
      WHERE event_date >= CURRENT_DATE
      ORDER BY event_date ASC, event_time ASC
    `;

    return Response.json({ 
      success: true, 
      events: events 
    });

  } catch (error) {
    console.error('Error fetching events:', error);
    return Response.json({ error: 'Failed to fetch events' }, { status: 500 });
  }
}