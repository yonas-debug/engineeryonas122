import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return Response.json({ error: 'Email and password are required' }, { status: 400 });
    }

    // Simple password hashing (same as registration)
    const passwordHash = Buffer.from(password).toString('base64');

    // Find student with matching email and password
    const result = await sql`
      SELECT id, full_name, email, phone, date_of_birth, education_level, interests, created_at
      FROM students 
      WHERE email = ${email} AND password_hash = ${passwordHash}
    `;

    if (result.length === 0) {
      return Response.json({ error: 'Invalid email or password' }, { status: 401 });
    }

    return Response.json({ 
      success: true, 
      student: result[0],
      message: 'Login successful!' 
    });

  } catch (error) {
    console.error('Login error:', error);
    return Response.json({ error: 'Login failed' }, { status: 500 });
  }
}