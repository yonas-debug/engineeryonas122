import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { fullName, email, phone, password, dateOfBirth, educationLevel, interests } = body;

    // Basic validation
    if (!fullName || !email || !password) {
      return Response.json({ error: 'Full name, email, and password are required' }, { status: 400 });
    }

    // Simple password hashing (in production, use bcrypt)
    const passwordHash = Buffer.from(password).toString('base64');

    // Check if email already exists
    const existingStudent = await sql`
      SELECT id FROM students WHERE email = ${email}
    `;

    if (existingStudent.length > 0) {
      return Response.json({ error: 'Email already registered' }, { status: 400 });
    }

    // Insert new student
    const result = await sql`
      INSERT INTO students (full_name, email, phone, password_hash, date_of_birth, education_level, interests)
      VALUES (${fullName}, ${email}, ${phone}, ${passwordHash}, ${dateOfBirth}, ${educationLevel}, ${interests})
      RETURNING id, full_name, email, phone, date_of_birth, education_level, interests, created_at
    `;

    return Response.json({ 
      success: true, 
      student: result[0],
      message: 'Registration successful!' 
    });

  } catch (error) {
    console.error('Registration error:', error);
    return Response.json({ error: 'Registration failed' }, { status: 500 });
  }
}